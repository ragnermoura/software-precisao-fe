<template>
  <div class="container">
    <pagination></pagination>
  </div>
</template>

<script>
import pagination from './pagination'
export default {
  components: {pagination},
  data () {
    return {

    }
  }
}
</script>
<style scoped>

</style>
