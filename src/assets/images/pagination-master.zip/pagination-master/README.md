# pagination

A plugin of [pagination](https://joriewong.github.io/pagination)
 using vue2.0

## Getting Started

Install dependencies.

``` bash
$ npm install
```

Start server.

``` bash
$ npm run dev
```